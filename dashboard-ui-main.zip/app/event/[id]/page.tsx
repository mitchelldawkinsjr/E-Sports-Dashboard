import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Users, Trophy, User, Clock } from "lucide-react"

export default function EventPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="ml-60 flex-1">
        {/* Hero Banner */}
        <div className="relative h-80 overflow-hidden border-b border-border">
          <div className="absolute inset-0 bg-[url('/american-football-stadium-night.jpg')] bg-cover bg-center" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
          <div className="relative flex h-full items-center justify-between px-8">
            <div className="max-w-2xl">
              <Badge className="mb-4 bg-yellow-500 text-black hover:bg-yellow-600">REGISTRATION OPEN</Badge>
              <h1 className="mb-4 text-4xl font-bold text-balance text-white">
                Madden NFL Youth Championship Qualifier Tournament #2
              </h1>
              <div className="flex gap-2">
                <Badge variant="secondary">ACTION/SPORTS</Badge>
                <Badge variant="secondary">TEAMS OF 1</Badge>
                <Badge variant="secondary">BEST OF 1</Badge>
              </div>
            </div>
            <div className="flex h-32 w-32 items-center justify-center rounded-full bg-white p-4">
              <div className="text-center">
                <div className="text-xs font-bold">MADDEN 26</div>
                <div className="text-2xl font-black">YOUTH</div>
                <div className="text-xs font-bold">CHAMPIONSHIP</div>
                <div className="mt-1 text-xs font-bold">QUALIFIER TWO</div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-border bg-card px-8">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="h-auto w-full justify-start rounded-none border-0 bg-transparent p-0">
              <TabsTrigger
                value="overview"
                className="rounded-none border-b-2 border-transparent px-4 py-4 data-[state=active]:border-primary data-[state=active]:bg-transparent"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="standings"
                className="rounded-none border-b-2 border-transparent px-4 py-4 data-[state=active]:border-primary data-[state=active]:bg-transparent"
              >
                Standings
              </TabsTrigger>
              <TabsTrigger
                value="matches"
                className="rounded-none border-b-2 border-transparent px-4 py-4 data-[state=active]:border-primary data-[state=active]:bg-transparent"
              >
                Matches
              </TabsTrigger>
              <TabsTrigger
                value="my-teams"
                className="rounded-none border-b-2 border-transparent px-4 py-4 data-[state=active]:border-primary data-[state=active]:bg-transparent"
              >
                My Teams
              </TabsTrigger>
            </TabsList>

            <div className="absolute right-8 top-[22rem]">
              <Button size="lg" disabled className="bg-muted text-muted-foreground">
                Join This Event
              </Button>
              <p className="mt-2 text-xs text-muted-foreground">
                You do not meet the age requirement to join this event.
              </p>
            </div>

            <TabsContent value="overview" className="mt-0">
              <div className="grid gap-8 p-8 lg:grid-cols-3">
                <div className="lg:col-span-2">
                  <Card>
                    <CardContent className="p-6">
                      <h2 className="mb-4 text-2xl font-bold">Event Details</h2>
                      <h3 className="mb-3 text-xl font-bold">Qualifier Tournament #2 Registration is now open!</h3>
                      <p className="mb-4 text-sm">
                        <a href="#" className="text-primary hover:underline">
                          Join the Discord
                        </a>{" "}
                        to stay updated on the competition!
                      </p>
                      <div className="mb-6 h-px bg-border" />
                      <p className="mb-4 text-sm leading-relaxed text-muted-foreground">
                        The Madden NFL Youth Championship (MYC) Qualifier Tournaments are a series of 2 Madden NFL 26
                        qualifying tournaments that lead into virtual Finals on January 20th, 2026 for a chance to win a
                        trip to the 2026 Super Bowl. This tournament series is open to middle and high school students,
                        ages 13-18 across the United States and Canada (excluding Quebec) competing on the PlayStation
                        5, Xbox Series X|S, and PC versions of Madden NFL 26. The top 8 players from each of the 2
                        qualifiers will have the opportunity to compete in a virtual championship final to win a trip to
                        the 2026 Super Bowl.
                      </p>
                      <p className="text-sm leading-relaxed text-muted-foreground">
                        To prepare, check out the{" "}
                        <a href="#" className="text-primary hover:underline">
                          Match Instructions
                        </a>{" "}
                        & other helpful resources!
                      </p>
                    </CardContent>
                  </Card>

                  {/* Information Cards */}
                  <div className="mt-6 grid gap-4 md:grid-cols-2">
                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-3 flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                            <Calendar className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Information</p>
                            <p className="font-semibold">Registration ends: January 10, 2026</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-3 flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                            <Trophy className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Format</p>
                            <p className="font-semibold">Best of 1 • Teams of 1</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-3 flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                            <Clock className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Dates & Times</p>
                            <p className="font-semibold">Start: January 9, 2026</p>
                            <p className="font-semibold">End: January 13, 2026</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-3 flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                            <User className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Eligibility</p>
                            <p className="font-semibold">Ages 13 - 18</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Schedule Section */}
                  <Card className="mt-6">
                    <CardContent className="p-6">
                      <h3 className="mb-4 text-xl font-bold">Schedule</h3>
                      <div className="mb-4">
                        <h4 className="mb-2 font-semibold">Queue Matches</h4>
                        <p className="mb-3 text-2xl font-bold">Jan 09 - Jan 11</p>
                        <div className="grid gap-2 sm:grid-cols-4">
                          <div className="rounded-lg bg-secondary p-3">
                            <p className="text-xs text-muted-foreground">QUALIFIER QUEUE MATCH</p>
                            <p className="text-sm font-semibold">Jan 09</p>
                            <p className="text-sm font-semibold">5:00 PM EST</p>
                          </div>
                          <div className="rounded-lg bg-secondary p-3">
                            <p className="text-xs text-muted-foreground">QUALIFIER QUEUE MATCH</p>
                            <p className="text-sm font-semibold">Jan 09</p>
                            <p className="text-sm font-semibold">6:30 PM EST</p>
                          </div>
                          <div className="rounded-lg bg-secondary p-3">
                            <p className="text-xs text-muted-foreground">QUALIFIER QUEUE MATCH</p>
                            <p className="text-sm font-semibold">Jan 09</p>
                            <p className="text-sm font-semibold">8:00 PM EST</p>
                          </div>
                          <div className="rounded-lg bg-secondary p-3">
                            <p className="text-xs text-muted-foreground">QUALIFIER QUEUE MATCH</p>
                            <p className="text-sm font-semibold">Jan 10</p>
                            <p className="text-sm font-semibold">12:00 PM EST</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="mb-2 font-semibold">Bracket Play</h4>
                        <p className="mb-3 text-2xl font-bold">Jan 10 - Jan 12</p>
                        <p className="text-sm text-muted-foreground">BRACKET SIZE: 64 TEAMS, SINGLE ELIMINATION</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Steps Section */}
                <div className="space-y-4">
                  <Card>
                    <CardContent className="p-6">
                      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                        <div className="h-10 w-10 rounded-lg bg-primary" />
                      </div>
                      <p className="mb-2 text-xs font-bold text-primary">STEP 1</p>
                      <h3 className="mb-2 text-lg font-bold">Join the Event</h3>
                      <p className="text-sm text-muted-foreground">Squad up - create or join a team.</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                        <Users className="h-8 w-8" />
                      </div>
                      <p className="mb-2 text-xs font-bold text-primary">STEP 2</p>
                      <h3 className="mb-2 text-lg font-bold">Fill your roster</h3>
                      <p className="text-sm text-muted-foreground">Grab your team's link and invite your friends.</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                        <Trophy className="h-8 w-8" />
                      </div>
                      <p className="mb-2 text-xs font-bold text-primary">STEP 3</p>
                      <h3 className="mb-2 text-lg font-bold">Register</h3>
                      <p className="text-sm text-muted-foreground">Secure your spot by registering your team.</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="my-teams" className="mt-0">
              <div className="p-8">
                <div className="grid gap-8 lg:grid-cols-3">
                  <Card className="lg:col-span-2 flex flex-col items-center justify-center py-24">
                    <div className="mb-6 flex h-32 w-32 items-center justify-center rounded-2xl bg-secondary">
                      <div className="relative h-20 w-20">
                        <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-foreground" />
                        <div className="absolute left-0 top-0 h-4 w-4 rounded-full border-2 border-foreground" />
                        <div className="absolute right-0 top-0 h-4 w-4 rounded-full border-2 border-foreground" />
                        <div className="absolute bottom-0 left-0 h-4 w-4 rounded-full border-2 border-foreground" />
                        <div className="absolute bottom-0 right-0 h-4 w-4 rounded-full border-2 border-foreground" />
                      </div>
                    </div>
                    <h2 className="mb-2 text-2xl font-bold">Ready to compete?</h2>
                    <p className="mb-6 text-muted-foreground">Join and you can start building your dream team!</p>
                    <Button size="lg" disabled className="bg-muted text-muted-foreground">
                      Join This Event
                    </Button>
                    <p className="mt-2 text-xs text-muted-foreground">
                      You do not meet the age requirement to join this event.
                    </p>
                  </Card>

                  <div className="space-y-4">
                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                          <div className="h-10 w-10 rounded-lg bg-primary" />
                        </div>
                        <p className="mb-2 text-xs font-bold text-primary">STEP 1</p>
                        <h3 className="mb-2 text-lg font-bold">Join the Event</h3>
                        <p className="text-sm text-muted-foreground">Squad up - create or join a team.</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                          <Users className="h-8 w-8" />
                        </div>
                        <p className="mb-2 text-xs font-bold text-primary">STEP 2</p>
                        <h3 className="mb-2 text-lg font-bold">Fill your roster</h3>
                        <p className="text-sm text-muted-foreground">Grab your team's link and invite your friends.</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-xl bg-secondary">
                          <Trophy className="h-8 w-8" />
                        </div>
                        <p className="mb-2 text-xs font-bold text-primary">STEP 3</p>
                        <h3 className="mb-2 text-lg font-bold">Register</h3>
                        <p className="text-sm text-muted-foreground">Secure your spot by registering your team.</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
