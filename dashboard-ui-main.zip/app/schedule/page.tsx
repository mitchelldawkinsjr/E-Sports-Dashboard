import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "lucide-react"

export default function SchedulePage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="ml-60 flex-1">
        {/* Hero Section */}
        <div className="relative h-64 overflow-hidden border-b border-border">
          <div className="absolute inset-0 bg-[url('/rocket-league-car-racing.jpg')] bg-cover bg-center opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
          <div className="relative flex h-full flex-col justify-center px-8">
            <h1 className="mb-4 text-5xl font-bold text-white">Schedule</h1>
            <p className="text-lg text-muted-foreground">
              Keep up to date with your team's schedule, roster, and stats
            </p>
          </div>
        </div>

        <div className="p-8">
          {/* Filters */}
          <div className="mb-6 flex items-center gap-4">
            <Button variant="outline" className="gap-2 bg-transparent">
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 4h18M3 4v2M21 4v2M5 8h14M5 8v12h14V8"
                />
              </svg>
              All Esports
            </Button>
            <div className="flex-1" />
            <select className="rounded-lg border border-border bg-card px-4 py-2 text-sm">
              <option>Search for a Team</option>
            </select>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="upcoming" className="mb-6">
            <TabsList>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Empty State */}
          <Card className="flex flex-col items-center justify-center py-24">
            <div className="mb-6 flex h-32 w-32 items-center justify-center rounded-2xl bg-secondary">
              <Calendar className="h-16 w-16 text-muted-foreground" />
            </div>
            <h2 className="mb-2 text-2xl font-bold">No Schedule available</h2>
            <p className="mb-6 text-muted-foreground">You are not a part of any events for the current season.</p>
            <Button>Explore Events</Button>
          </Card>
        </div>
      </main>
    </div>
  )
}
