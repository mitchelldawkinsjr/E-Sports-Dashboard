import { Sidebar } from "@/components/sidebar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function SettingsPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="ml-60 flex-1 p-8">
        <h1 className="mb-8 text-3xl font-bold">Account Settings</h1>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="mb-8">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="connections">Connections</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-8">
            {/* Personal Information */}
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-6 text-xl font-bold">Personal Information</h2>
                <div className="mb-6 flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src="/placeholder.svg?height=80&width=80" />
                    <AvatarFallback className="bg-primary text-2xl text-primary-foreground">GP</AvatarFallback>
                  </Avatar>
                  <Button variant="outline">Upload Avatar</Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" defaultValue="Mitchell" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" defaultValue="Dawkins" />
                  </div>
                  <div>
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input id="displayName" defaultValue="gamerpro" />
                  </div>
                  <div>
                    <Label htmlFor="dob">Date of Birth</Label>
                    <Input id="dob" type="date" defaultValue="1991-04-03" />
                  </div>
                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Input id="country" defaultValue="US" />
                  </div>
                  <div>
                    <Label htmlFor="state">Select State</Label>
                    <Input id="state" defaultValue="MI" />
                  </div>
                </div>
                <div className="mt-6 flex justify-end">
                  <Button>Save Changes</Button>
                </div>
              </CardContent>
            </Card>

            {/* Security & Privacy */}
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-6 text-xl font-bold">Security & Privacy</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between rounded-lg border border-border p-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-primary text-primary-foreground">GP</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">Personal Email</p>
                        <div className="flex items-center gap-2">
                          <p className="text-sm text-muted-foreground">mitchell.dawkins@gmail.com</p>
                          <Badge variant="secondary" className="text-xs">
                            UNVERIFIED
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Resend Email
                      </Button>
                      <Button variant="outline" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border border-border p-4">
                    <div>
                      <p className="text-sm font-medium">Password</p>
                      <p className="text-sm text-muted-foreground">••••••••</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="connections" className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-6 text-xl font-bold">Platform Connections</h2>
                <div className="space-y-4">
                  {[
                    {
                      name: "Riot Games",
                      description:
                        "Connect your Riot Games account to participate in matches for League of Legends and VALORANT.",
                      icon: "🎮",
                    },
                    {
                      name: "Epic Games",
                      description: "Connect your Epic Games account to participate in Rocket League matches.",
                      icon: "🎮",
                    },
                    {
                      name: "Nintendo",
                      description: "Add your Nintendo friend code. (Ex: SW-0000-0000-0000)",
                      icon: "🎮",
                      hasInput: true,
                    },
                    {
                      name: "Twitch",
                      description: "Connect your Twitch account to submit a clip",
                      icon: "📺",
                    },
                    {
                      name: "YouTube",
                      description: "Connect your YouTube account to submit a clip",
                      icon: "📺",
                    },
                    {
                      name: "Chess.com",
                      description: "Add your Chess.com username",
                      icon: "♟",
                      hasInput: true,
                    },
                  ].map((platform) => (
                    <div
                      key={platform.name}
                      className="flex items-center justify-between rounded-lg border border-border p-4"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary text-2xl">
                          {platform.icon}
                        </div>
                        <div>
                          <p className="font-semibold">{platform.name}</p>
                          <p className="text-sm text-muted-foreground">{platform.description}</p>
                          {platform.hasInput && (
                            <Input className="mt-2 max-w-xs" placeholder={`${platform.name} username`} />
                          )}
                        </div>
                      </div>
                      <Button>Connect</Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardContent className="p-6">
                <h2 className="mb-6 text-xl font-bold">Notification Preferences</h2>
                <p className="text-muted-foreground">Notification settings coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
