import { Sidebar } from "@/components/sidebar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Calendar, Users, Zap } from "lucide-react"
import Link from "next/link"

export default function CompetitionsPage() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="ml-60 flex-1">
        {/* Hero Section */}
        <div className="relative h-64 overflow-hidden border-b border-border bg-gradient-to-r from-card via-cyan-950/30 to-card">
          <div className="absolute inset-0 bg-[url('/gaming-arena-abstract.jpg')] bg-cover bg-center opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/50" />
          <div className="relative flex h-full flex-col items-center justify-center px-8 text-center">
            <Badge className="mb-4 bg-primary text-primary-foreground shadow-lg shadow-primary/50">
              <Zap className="mr-1 h-3 w-3" />
              Season 2026
            </Badge>
            <h1 className="mb-4 text-5xl font-bold text-balance">Compete at the Highest Level</h1>
            <p className="text-lg text-muted-foreground text-pretty">
              Join elite tournaments and prove your skills against the best players worldwide
            </p>
          </div>
        </div>

        <div className="p-8">
          {/* Upcoming Events */}
          <section className="mb-12">
            <h2 className="mb-6 text-2xl font-bold">Upcoming Events</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Link href="/event/1">
                <Card className="group overflow-hidden transition-all hover:border-primary hover:shadow-xl hover:shadow-primary/20">
                  <div className="relative h-48 overflow-hidden bg-gradient-to-br from-pink-500 via-red-500 to-yellow-500">
                    <Badge className="absolute right-3 top-3 bg-black/50 text-white backdrop-blur-sm">
                      Registration Open
                    </Badge>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <div className="mb-2 text-6xl font-black text-white drop-shadow-lg">QUALIFIER TWO</div>
                        <div className="text-sm font-bold text-white/90">
                          COMPETE FOR A CHANCE TO WIN A TRIP TO SUPER BOWL LX
                        </div>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="mb-3">
                      <h3 className="mb-2 text-lg font-bold leading-tight group-hover:text-primary transition-colors">
                        Madden NFL Youth Championship Qualifier Tournament #2
                      </h3>
                      <div className="flex gap-2">
                        <Badge variant="secondary" className="text-xs">
                          Action/Sports
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          Teams of 1
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Trophy className="h-4 w-4 text-primary" />
                        <span>1v1</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-primary" />
                        <span>Best of 1</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-primary" />
                        <span>Jan 9</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>

              <Card className="overflow-hidden transition-all hover:border-primary hover:shadow-xl hover:shadow-primary/20">
                <div className="relative h-48 overflow-hidden bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600">
                  <Badge className="absolute right-3 top-3 bg-black/50 text-white backdrop-blur-sm">Coming Soon</Badge>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-4xl font-black text-white drop-shadow-lg">SPRING SHOWDOWN</div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="mb-2 text-lg font-bold">Rocket League Spring Invitational</h3>
                  <div className="mb-3 flex gap-2">
                    <Badge variant="secondary" className="text-xs">
                      Racing
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      Teams of 3
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Trophy className="h-4 w-4 text-primary" />
                      <span>3v3</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-primary" />
                      <span>Best of 3</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span>Feb 15</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-hidden transition-all hover:border-primary hover:shadow-xl hover:shadow-primary/20">
                <div className="relative h-48 overflow-hidden bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-600">
                  <Badge className="absolute right-3 top-3 bg-black/50 text-white backdrop-blur-sm">Coming Soon</Badge>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-4xl font-black text-white drop-shadow-lg">LEAGUE CHAMPIONSHIP</div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="mb-2 text-lg font-bold">League of Legends Collegiate Finals</h3>
                  <div className="mb-3 flex gap-2">
                    <Badge variant="secondary" className="text-xs">
                      MOBA
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      Teams of 5
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Trophy className="h-4 w-4 text-primary" />
                      <span>5v5</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4 text-primary" />
                      <span>Best of 5</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span>Mar 1</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Ongoing Events */}
          <section>
            <h2 className="mb-6 text-2xl font-bold">Ongoing Events</h2>
            <Card className="flex flex-col items-center justify-center py-16 border-dashed">
              <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5">
                <Trophy className="h-12 w-12 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-bold">No Events Yet</h3>
              <p className="text-muted-foreground">Check back soon for the next event!</p>
            </Card>
          </section>
        </div>
      </main>
    </div>
  )
}
